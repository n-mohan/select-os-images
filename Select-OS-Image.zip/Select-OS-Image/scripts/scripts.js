$(function ($) {

    var dH = $(document).height();
		$('.left-nav-main').css({
			height: dH - 75
        });

    /* Manage Instance Page Control Toggle Script */
	$('.instance-control table tr').nextUntil('tr.pinned').hide();
	$('.instance-control .show-more').on('click', function() {
   		$('.instance-control table tr').closest('.instance-control table tr').nextUntil('tr.pinned').slideToggle(50)//.lftHtAdjst;
		$('span.show-more i').text($(this).text() == 'More details' ? 'Less details' : 'More details');
		$('span.show-more em').toggleClass('Neuelessdetails');
		
	});
    
    // Settings Tab Show/Less More scripts
    $('.tabs-main .show-more').on('click', function(){
        $('.tabs-main span.show-more i').text($(this).text() == 'More details' ? 'Less details' : 'More details');
		$(' span.show-more em').toggleClass('Neuelessdetails');
        $('.tabs-main .win-steps').toggle();        
    });
    
    // STORAGE SLIDER
    var $slider = $( '.storage-slider input' );
    $slider.on( 'input', function( ) {
      $(this).css( 'background', 'linear-gradient(to right, #38a505 0%, #38a505 '+this.value +'%, #fff ' + this.value + '%, #fff 100%)' );
      
      var $value = $slider.val();
      $('#output em').html($value); // Printing Slider Value
    });
    
    
    
    //$("#download-key-Modal").modal('show');
    
    
    /**** ADVANCED OPTIONS - SUBNET SCRIPTS ******/
    var $advOpt = $('#adv-opt');
    var $subnetMain = $('.subnet-main');
    $subnetMain.hide(); // Hiding By Default
    
    $($advOpt).on('click', function(){
        $('.subnet-main').toggle();
         $('.Neuemoredetails').toggleClass('Neuelessdetails');
    });
    
    // ToolTip
    
    $('[data-toggle="tooltip"]').tooltip();  

});




